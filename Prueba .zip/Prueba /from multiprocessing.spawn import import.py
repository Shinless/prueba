from multiprocessing.spawn import import_main_path
import numpy as np
from  funciones import menu
menu()